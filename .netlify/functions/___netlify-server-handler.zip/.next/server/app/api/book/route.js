var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/book/route.js")
R.c("server/chunks/[root-of-the-server]__202625d9._.js")
R.c("server/chunks/[root-of-the-server]__4f2f97b0._.js")
R.c("server/chunks/[root-of-the-server]__703022d1._.js")
R.m(83521)
R.m(62923)
module.exports=R.m(62923).exports
