globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/233823f5bb8faa75.js",
      "static/chunks/turbopack-19c70f602868a723.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/233823f5bb8faa75.js",
      "static/chunks/turbopack-348410f2e5fcee49.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/708dfc0609e1343f.js",
    "static/chunks/6c1d949039ca8e4a.js",
    "static/chunks/47f477e3d2ef265b.js",
    "static/chunks/turbopack-c560507fbe4e4ec3.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];